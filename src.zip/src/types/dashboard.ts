export interface DashboardKpis {
  activeOrders: number;
  activeBatches: number;
  completedToday: number;
  lateBatches: number;
  totalOrders: number;
}
