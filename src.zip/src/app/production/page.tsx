export default function ProductionPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Production</h2>
      <p className="text-sm text-muted-foreground">
        This page is a placeholder for the Production view.
      </p>
    </div>
  );
}
