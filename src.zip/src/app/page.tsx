import { DashboardContainer } from "@/components/dashboard/DashboardContainer";

export default function Page() {
  return <DashboardContainer />;
}
