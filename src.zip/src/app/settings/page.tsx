export default function SettingsPage() {
  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold">Settings</h2>
      <p className="text-sm text-muted-foreground">
        This page is a placeholder for the Settings view.
      </p>
    </div>
  );
}
